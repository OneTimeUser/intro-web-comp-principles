//I use 'body' a lot so I decided to make it global!!!
const background = document.querySelector('body');


/*
Dark Mode for Seasons Home Page
*/

let hour = new Date().getHours(); // get current hour
// console.log(hour); // display current hour in the web console

if (hour >= 18 || hour < 6) { // between 6:00 PM and 6:00 AM
  // if (hour > 6) { // testing dark mode during the day
  background.style.backgroundColor = 'black'; // change background color to white with style object
  background.style.color = 'white'; // change default font color of all child elements to white

  const header = document.querySelector('h1 > a'); // access <a> element of main heading
  header.className = 'dark'; // apply class of "dark" (see style sheet)

  const navigation = document.querySelectorAll('nav > a'); // access <a> elements of primary navigation

  navigation[0].className = 'dark'; // spring
  navigation[1].className = 'dark'; // summer
  navigation[2].className = 'dark'; // fall
  navigation[3].className = 'dark'; // winter

  const footer = document.querySelector('footer > p > a') // access <a> element of footer paragraph
  footer.className = 'dark'; // apply class of "dark"
}

/*
Changing Image Opacity
*/

//grab all of the images
let images = document.querySelectorAll("main > a > img");
console.log(images);

function changeOpacity() {
  images[0].style.opacity = "0.5";
  images[1].style.opacity = "0.5";
  images[2].style.opacity = "0.5";
  images[3].style.opacity = "0.5";

  //for event handlers: 'this' refers the html element that received the event
  this.style.opacity = '1'; //keep current image under cursor opaque
}

function resetOpacity() {
  images[0].style.opacity = "1";
  images[1].style.opacity = "1";
  images[2].style.opacity = "1";
  images[3].style.opacity = "1";
}

//Fun Mode Theming!!!!!
let btn = document.querySelector('button');

let randImages = document.querySelector('#random-images');

//after class, as I was cleaning this up, I realized that I dont
//want images just to show up on the visible parts of the screen...
//so for the height, I want to use the body height instead
let intViewportWidth = window.innerWidth; //grabs width in pixels of browser window
let intBodyHeight = background.offsetHeight; //grabs height in pixels of the background variable defined at the very top of this page

let imgs = [
  "https://i.pinimg.com/originals/2b/66/64/2b6664a2d87b7ee7abef3b60e1d76c97.gif",
  "https://media0.giphy.com/media/S9RNRQxONtaPwBTVff/giphy.gif",
  "https://acegif.com/wp-content/gif/unicorn-92.gif",
  "https://i1.wp.com/boingboing.net/wp-content/uploads/2015/07/unicorn_riding_rainbow_by_k_rui-d3lmuln.gif?resize=343%2C276",
  "https://acegif.com/wp-content/gif/unicorn-46.gif",
  "https://media2.giphy.com/media/8c14vDYQEMkx6zvLh1/source.gif",
  "https://media4.giphy.com/media/JQqI2eHKFXRoOH7QTP/source.gif",
  "https://64.media.tumblr.com/345dfbca5c6558379fcbc17cdc795557/tumblr_ou6l1c7hvI1qbmm1co1_1280.gifv",
  "https://media1.giphy.com/media/l49JNAlwkjTa8rRiE/giphy.gif",
  "https://think-unicorn.com/wp-content/uploads/2020/02/unicorn-is-dancing.gif",
  "https://www.animatedimages.org/data/media/477/animated-unicorn-image-0026.gif"
];



//anmimated bg and change of font and font color
//I also moved my random images in here so it randomizes EACH TIME HECK YEAH
function activateFun() {

  let text = document.querySelectorAll('a');
  let body = document.querySelector('body');



  //logic for changing text
  //for loop for iterating over lists of items
  for (let i = 0; i < text.length; i++) {
    text[i].classList.toggle('fun-text');
  }

  body.classList.toggle('fun-bg');

  randImages.classList.toggle('fun-images');

  //IT WORKS....
  if (randImages.className === "fun-images") {
    btn.textContent = "Activate Fun";
  } else {
    btn.textContent = "Deactivate Fun";
  }

  let img = ' ';
  //console.log(btn);
  for (let i = 0; i < imgs.length; i++) {

    let positiontop = (Math.random() * (intBodyHeight - 100)) + 50; //added some buffer (50px)here to prevent the liklihood of image appearing offscreen
    let positionright = (Math.random() * (intViewportWidth - 100)) + 50; //so this essentially picks a random number between 50 and width or height -50 (100-50)
    let zindex = i;

    img += '<img class="fun-img" src="' + imgs[i] + '" style="top:' + positiontop + 'px; right:' + positionright + 'px; z-index:' + zindex + ';">'
  }

  randImages.innerHTML = img;
}

btn.addEventListener('click', activateFun);

//event listeners for hover on
images[0].addEventListener('mouseover', changeOpacity);
images[1].addEventListener('mouseover', changeOpacity);
images[2].addEventListener('mouseover', changeOpacity);
images[3].addEventListener('mouseover', changeOpacity);

//event listeners for hover off
images[0].addEventListener('mouseout', resetOpacity);
images[1].addEventListener('mouseout', resetOpacity);
images[2].addEventListener('mouseout', resetOpacity);
images[3].addEventListener('mouseout', resetOpacity);