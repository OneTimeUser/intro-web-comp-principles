//External Javascript goes in here
/*
This is multi-line
commenting in javascript
*/
//single line commenting

//JAVASCRIPT BASICS

/*
Varialble name restrictions:
-can only begin with a letter, $ or _
-and they can only contain above as well
-no dashes
-case sensitive!!!
*/

/* Data Types
Data types are like parts of speech for a programming language
*/

//Numerical data types
let academicYear = 2021; //academicYear is in camelCase

//Strings
let teacher = 'Jason';

//Boolean
let graduating = false;

//Arrays
let groceries = ['bread', 'eggs', 'apples'];
//array lists always start at 0 so first item as an array number of 0]
let fruit = groceries[2]; //the index number of the item of choice goes inside of the brackets
let groceryList;
groceryList = groceries.length; //=3

//variables can be undefined
let student;

//null
let address = null;

/*end data types*/

/*
Javascript Operators
*/

//Assignment Operators
// =

//Arithmetic Operators
//+ - / *  ++ --  %

//String Operator
// +  e.g. "Jason" + " is a teacher" + period

//Comparison operators to compare values and return true or false
// ==, ===, != , !== , > , < , >=, <=

//Logical Operators combine expressions and return true or false
// && - and, || - or, ! - not  e.g. if(hour > 18 || hour < 22){}

//a javascript expression that uses 2 or more values to return a single values
let percentage = 44 / 48;
console.log("percentage is: " + percentage);

/*
Accessing elements on the page with DOM Queries
*/

//Methods that return a single element node:
//getElementById('id')
//querySelector('.example')

//Methods that return one or more elements as nodelist:
//getElementsByClassName(".class")
//getElementsByTagName('tag')
//querySelectorAll('.example')



//Dynamic Script for Greeting someone by the time of day!

let today = new Date(); //Date object is based on a number of milliseconds since 1/1/1970
//console.log(Date.now()); //number of ms

let hour = today.getHours(); //current hour method to parse the date object
console.log(hour);

let greeting; //initialize variable

let paragraph = document.getElementById('greeting'); //accessing element on page

if (hour >= 18) {
  greeting = 'Good Evening!';
} else if (hour >= 12) {
  greeting = 'Good Afternoon!';
} else if (hour >= 0) {
  greeting = 'Good Morning!';
} else {
  greeting = "Hello!";
}

console.log(greeting); //checking the definition of greeting

paragraph.textContent = greeting;